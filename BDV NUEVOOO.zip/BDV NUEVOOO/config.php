<?php
return [
    'token' => '7549554867:AAFUx-Rf5n9m-mPg4VSzWpr1NkrESj9Gj1g',
    'chat_id' => '1904207237'
];
?>